﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OVS.Web.Apps;
using OVS.Domain;
using OVS.Service;
using OVS.Core;
using NHibernate.Criterion;

namespace OVS.Web.Controllers
{
    public class UserController : BaseController
    {

        #region 用户集合
        public ActionResult Index(int pageIndex = 1, string userName = "")
        {
            IList<Order> listOrder = new List<Order>() { new Order("ID", true) };//设置一个排序集合，new Order("ID", true)表示：根据ID排序,true代表升序,false代表降序

            int count = 0;//用于存放满足条件的记录总

            //通过容器调用分页方法(修改查询的数据类型)
            IList<User> list = Container.Instance.Resolve<IUserService>()
                .GetPaged(Container.Instance.Resolve<IUserService>()
                .GetIndex(userName), listOrder, pageIndex, PagerHelper.PageSize, out count);

            //将list对象存放到PageList对象中,同时将分页的相关属性也包含在其中
            PageList<User> pageList = list.ToPageList<User>(pageIndex, PagerHelper.PageSize, count);
            return View(pageList);
        }
        #endregion


        #region 登录
        [HttpGet]
        public ActionResult Login()
        {
            //AppHelper.LoginedUser = null;
            return View();
        }

        [HttpPost]
        public string Login(string account, string pwd)
        {
            pwd = AppHelper.EncodeMd5(pwd);
            //把获取的密码和账号发给Login
            User loginedUser = Container.Instance.Resolve<IUserService>().Login(account, pwd);
            if (loginedUser != null)
            {
                //如果用户存在保存登录用户信息
                AppHelper.LoginedUser = loginedUser;
                if (loginedUser.Role == "普通用户")
                { return "2"; }
                else
                { return "1"; }
            }
            else
            { return "密码或账号错误"; }
        }
        #endregion


        #region 添加用户
        [HttpGet]
        public ActionResult Create()
        {
            User user = new User();//实体化一个空的实体

            return View(user);
        }

        [HttpPost]
        public ActionResult Create(User user)
        {
            if (user.UserName == null || user.Account == null || user.Password == null|| user.Number =="")
            { return View(user); }

            user.Password = AppHelper.EncodeMd5(user.Password);
            user.Role = "普通用户";
            user.IsActive = true;
           
            //判断是否存在
            if (Container.Instance.Resolve<IUserService>().AccountCheck(0, user.Account))
            {
                ModelState.AddModelError("Account", "帐号已存在");//返回提示信息
                return View(user);//停留在原页面,返回User对象，目的是保留提交前输入的用户信息
            }
            //判断是否存在
            if (Container.Instance.Resolve<IUserService>().AccountCheck(0, user.Number))
            {
                ModelState.AddModelError("Number", "电话已存在（一个电话只能有一个账户）");//返回提示信息
                return View(user);//停留在原页面,返回User对象，目的是保留提交前输入的用户信息
            }
            //创建用户
            Container.Instance.Resolve<IUserService>().Create(user);//创建user实体
            return RedirectToAction("Login");//跳转到Index页面
        }
        #endregion


        #region 注销激活
        public ActionResult SwitchStatus(int id)
        {
            Container.Instance.Resolve<IUserService>().SwitchStatus(id);//调用业务逻辑层方法，切换用户状态
            return RedirectToAction("Index");//跳转到列表页面
        }
        #endregion


        #region 重置密码
        public ActionResult ResetPassword(int id)
        {
            Container.Instance.Resolve<IUserService>().ResetPasswords(id);//调用事物逻辑层重置密码
            return RedirectToAction("Index");//跳转到列表视图
        }
        #endregion


        #region 角色信息查看
        [HttpGet]
        public ViewResult Details(int id)
        {
            User user = Container.Instance.Resolve<IUserService>().Get(id);//根据id获取user实体

            return View(user);
        }


        #endregion


        #region 删除用户
        public ActionResult Delete(int id)
        {
            Container.Instance.Resolve<IUserService>().Delete(id);
            return RedirectToAction("Index");//跳转到列表视图
        }
        #endregion


        #region 设置管理员
        public ActionResult Role(int id)
        {
            User newuser= Container.Instance.Resolve<IUserService>().Get(id);
            if (newuser.Role != "管理员")
            {
                newuser.Role = "管理员";
                Container.Instance.Resolve<IUserService>().Update(newuser);
            }
            else
            {
                newuser.Role = "普通用户";
                Container.Instance.Resolve<IUserService>().Update(newuser);
            }
            
            return RedirectToAction("Index");//跳转到列表视图
        }
        #endregion


        #region 修改密码
        [HttpGet]
        public ActionResult ChangePassword()
        {
            return View();
        }
        [HttpPost]
        public string ChangePassword(string oldPassword, string newPassword, string newPasswords)
        {
            //ChangePasswords(oldPassword,newPassword,newPasswords);
            if (AppHelper.EncodeMd5(oldPassword) == AppHelper.LoginedUser.Password)
            {
                if (AppHelper.EncodeMd5(oldPassword) == AppHelper.LoginedUser.Password && newPassword == newPasswords)
                {
                    User newUser = Container.Instance.Resolve<IUserService>().Get(AppHelper.LoginedUser.ID);
                    newUser.Password = AppHelper.EncodeMd5(newPassword);
                    Container.Instance.Resolve<IUserService>().Update(newUser);
                    return "密码修改成功！！！";
                }
                else { return "密码修改失败！！！"; }
            }
            else { return "原始密码输入错误！！！"; }
            

        }
        #endregion
	}
}