﻿using NHibernate.Criterion;
using OVS.Core;
using OVS.Domain;
using OVS.Service;
using OVS.Web.Apps;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OVS.Web.Controllers
{
    public class PlayerController : BaseController
    {
        #region 参赛者集合
        public ActionResult Index(int pageIndex = 1, string playerName = "")
        {
            IList<Order> listOrder = new List<Order>() { new Order("ID", true) };//设置一个排序集合，new Order("ID", true)表示：根据ID排序,true代表升序,false代表降序

            int count = 0;//用于存放满足条件的记录总

            //组织查询条件(必须的修改)
            IList<ICriterion> queryConditions = new List<ICriterion>();
            //判断是否为空
            if (!string.IsNullOrEmpty(playerName))
            {
                queryConditions.Add(new LikeExpression("PlayerName", playerName));
            }

            //通过容器调用分页方法(修改查询的数据类型)
            IList<Player> list = Container.Instance.Resolve<IPlayerService>()
                .GetPaged(queryConditions, listOrder, pageIndex, PagerHelper.PageSize, out count);

            //将list对象存放到PageList对象中,同时将分页的相关属性也包含在其中
            PageList<Player> pageList = list.ToPageList<Player>(pageIndex, PagerHelper.PageSize, count);

            return View(pageList);
        }
        #endregion

        #region 添加参赛者
        [HttpGet]
        public ActionResult Create()
        {
            Player user = new Player();//实体化一个空的实体

            return View(user);
        }

        [HttpPost]
        public ActionResult Create(Player player)
        {
            player.Picture = "~/Contents/Playre/mr.jpg";
            //if (ModelState.IsValid)
            {
                Container.Instance.Resolve<IPlayerService>().Create(player);//创建user实体
                return RedirectToAction("Index");//跳转到Index页面

            }
            //else { return View(player); }//跳转到Index页面}
           
        }
        #endregion

        #region 删除参赛者
        public ActionResult Delete(int id)
        {
            List<ICriterion> queryConditions1 = new List<ICriterion>();
            queryConditions1.Add(Expression.Eq("Player.ID", id));
            if (Container.Instance.Resolve<IPlayeringService>().Get(queryConditions1) == null)
            {
                Container.Instance.Resolve<IPlayerService>().Delete(id);
                return RedirectToAction("Index");//跳转到列表视图
            }
            return Content("<script>alert('该艺人正在参加比赛，请先删除比赛！！');location.href='/Player/Index'</script>");
        }
        #endregion

        #region 修改基本信息

        public ActionResult Edit(int id)
        {
            Player player = Container.Instance.Resolve<IPlayerService>().Get(id);//根据id获取user实体
            return View("Create", player);
        }

        [HttpPost]
        public ActionResult Edit(Player model)
        {
            Player player = Container.Instance.Resolve<IPlayerService>().Get(model.ID);//根据id获取user实体
            player.PlayerName = model.PlayerName;
            player.Age = model.Age;
            player.Role = model.Role;
            player.Introduction = model.Introduction;
            player.Sex = model.Sex;
            Container.Instance.Resolve<IPlayerService>().Update(player);//更新数据库
            return RedirectToAction("Index");//跳转到列表视图
        }
        #endregion

        #region 信息查看
        [HttpGet]
        public ViewResult Details(int id)
        {
            Player player = Container.Instance.Resolve<IPlayerService>().Get(id);//根据id获取user实体

            return View(player);
        }


        #endregion
	}
}