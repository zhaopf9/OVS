﻿using NHibernate.Criterion;
using OVS.Core;
using OVS.Domain;
using OVS.Service;
using OVS.Web.Apps;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OVS.Web.Controllers
{
    public class CompetitionController : BaseController
    {
        #region 比赛集合
        public ActionResult Index(int pageIndex = 1, string userName = "")
        {
            IList<Order> listOrder = new List<Order>() { new Order("ID", true) };//设置一个排序集合，new Order("ID", true)表示：根据ID排序,true代表升序,false代表降序

            int count = 0;//用于存放满足条件的记录总

            //通过容器调用分页方法(修改查询的数据类型)
            IList<Competition> list = Container.Instance.Resolve<ICompetitionService>().GetPaged(null, listOrder, pageIndex, PagerHelper.PageSize, out count);

            //将list对象存放到PageList对象中,同时将分页的相关属性也包含在其中
            PageList<Competition> pageList = list.ToPageList<Competition>(pageIndex, PagerHelper.PageSize, count);

            return View(pageList);
        }
        #endregion


        #region 添加比赛
        [HttpGet]
        public ActionResult Create(int pageIndex=1)
        {
            IList<Player> lists = Container.Instance.Resolve<IPlayerService>().GetAll();

            return View(lists);
        }

        [HttpPost]
        public ActionResult Create(string hdSelectedIds, string name, string place, DateTime hitime, string lotime)
        {
            Competition competition = new Competition();//实体化一个空的实体
            competition.Playeringlist = new List<Playering>() { new Playering() };
            competition.IsActive = "进行中";
            competition.BTime = hitime;
            competition.RTime = int.Parse(lotime);
            competition.Place = place;
            competition.ThemeName = name;

            string rolesId = hdSelectedIds.Replace(",,", ",");
            if (!string.IsNullOrEmpty(hdSelectedIds))
            {
                
                string[] ids = rolesId.Split(new char[] { ',', '_', '|' });//将id值拆分到数组里面
                if (ids.Count() > 23||ids.Count()<=3)
                {
                    return Content("<script>alert('比赛人员不得多于二十人或者小于两人！！');location.href='/Competition/Create'</script>");
                }
                foreach (string tempId in ids)
                {
                    //判断是否为空
                    if (string.IsNullOrEmpty(tempId))
                        continue;

                    //创建比赛
                    Playering playering = new Playering();
                    playering.Player = Container.Instance.Resolve<IPlayerService>().Get(int.Parse(tempId));
                    playering.Poll = 0;
                    playering.Competition = competition;
                    //会存入一条空数据后期删除
                    competition.Playeringlist.Add(playering);
                }
               
            }

            competition.Playeringlist.RemoveAt(0);//删除第一条为空数据
            Container.Instance.Resolve<ICompetitionService>().Create(competition);
            return RedirectToAction("Index");//跳转到Index页面
        }
        #endregion


        #region 删除比赛
        public ActionResult Delete(int id)
        {
            Container.Instance.Resolve<ICompetitionService>().Delete(id);
            return RedirectToAction("Index");//跳转到列表视图
        }
        #endregion


        #region 结束比赛
        public ActionResult Over(int id, int pageIndex = 1)
        {

            Competition competition = Container.Instance.Resolve<ICompetitionService>().Get(id);
            //1.比赛结束修改
            competition.IsActive = "结束";
            Container.Instance.Resolve<ICompetitionService>().Update(competition);

            //2.结果添加
            Result result = new Result();
            result.CompetitionId = competition.ID;
            //result.Playeringlist = playering.Competition.Playeringlist;
            //2.1结果写入数据库
            Container.Instance.Resolve<IResultService>().Create(result);

            //提供比赛
            IList<Competition> competitionName = Container.Instance.Resolve<ICompetitionService>().GetAll();
            ViewBag.themelist = competition;

            return RedirectToAction("Index");//跳转到列表视图
        }
        #endregion


        #region 比赛结果
        public ActionResult Result(int id, int pageIndex = 1)
        {

            List<ICriterion> queryConditions1 = new List<ICriterion>();
            queryConditions1.Add(Expression.Eq("Competition.ID", id));
            IList<Order> listOrder = new List<Order>() { new Order("Poll", false) };//设置一个排序集合，new Order("ID", true)表示：根据ID排序,true代表升序,false代表降序
            int count = 0;//用于存放满足条件的记录总
            IList<Playering> list = Container.Instance.Resolve<IPlayeringService>().GetPaged(queryConditions1, listOrder, pageIndex, 20, out count);
            PageList<Playering> pageList = list.ToPageList<Playering>(pageIndex, PagerHelper.PageSize, count);
            return View(pageList);

        }
        #endregion


        
	}
}