﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Castle.ActiveRecord;

using System.ComponentModel.DataAnnotations;

namespace OVS.Domain
{
    [ActiveRecord("Playering")]
    public class Playering:EntityBase
    {
        //参赛者
        [BelongsTo(Type = typeof(Player), Column = "PlayerId", Lazy = FetchWhen.OnInvoke)]
        public Player Player { get; set; }

        [Property(NotNull = true)]
        [Display(Name = "票数", Description = "票数")]
        public virtual int Poll { get; set; }

        //主题
        [BelongsTo(Type = typeof(Competition), Column = "CompetitionId", Lazy = FetchWhen.OnInvoke)]
        public Competition Competition { get; set; }
    }
}
