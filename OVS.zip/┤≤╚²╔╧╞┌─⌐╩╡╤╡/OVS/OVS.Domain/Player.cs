﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Castle.ActiveRecord;

using System.ComponentModel.DataAnnotations;

namespace OVS.Domain
{
    [ActiveRecord("Player")]
    public class Player : EntityBase
    {
        [Property(NotNull = true)]
        [Required(ErrorMessage = "不能为空")]
        [StringLength(20, ErrorMessage = "不能超过20个字符")]
        [Display(Name = "姓名")]
        public virtual string PlayerName { get; set; }

        [Property(NotNull = true)]
        [Required(ErrorMessage = "不能为空")]
        [Display(Name = "Age", Description = "年龄")]
        public virtual int Age { get; set; }

        [Property(NotNull = true)]
        [Required(ErrorMessage = "不能为空")]
        [Display(Name = "角色")]
        public virtual string Role { get; set; }

        [Property(NotNull = true)]
        [Required(ErrorMessage = "不能为空")]
        [Display(Name = "性别")]
        public virtual string Sex { get; set; }

        [Property(NotNull = true)]
        [Required(ErrorMessage = "不能为空")]
        [Display(Name = "简介")]
        public virtual string Introduction { get; set; }

        [Property(NotNull = true)]
        [Required(ErrorMessage = "不能为空")]
        [Display(Name = "图片")]
        public virtual string Picture { get; set; }

        //[BelongsTo(Type = typeof(Result), Column = "ResultId", Lazy = FetchWhen.OnInvoke)]
        //public Result Result { get; set; }

        
    }
}
