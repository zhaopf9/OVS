﻿using NHibernate.Criterion;
using OVS.Core;
using OVS.Domain;
using OVS.Service;
using OVS.Web.Apps;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OVS.Web.Controllers
{
    public class ResultController : Controller
    {

        #region 参赛者集合
        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }
        [HttpPost]
        public ActionResult Index(string hdSelectedIds)
        {
            
            return View();
        }
        #endregion
	}
}