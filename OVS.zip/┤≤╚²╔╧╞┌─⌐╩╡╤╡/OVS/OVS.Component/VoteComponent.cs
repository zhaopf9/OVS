﻿using Manager;
using OVS.Domain;
using OVS.Service;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OVS.Component
{
    public class VoteComponent : BaseComponent<Vote, VoteManager>, IVoteService
    {

    }
}



