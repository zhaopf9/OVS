﻿using OVS.Domain;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OVS.Service
{
    public interface IResultService: IBaseService<Result>
    {
    }
}
