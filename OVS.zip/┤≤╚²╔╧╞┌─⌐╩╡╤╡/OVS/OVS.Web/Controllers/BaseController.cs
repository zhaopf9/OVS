﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using OVS.Web.Apps;
using OVS.Domain;
using NHibernate.Criterion;
using OVS.Core;
using OVS.Service;


namespace OVS.Web.Controllers
{
    public class BaseController : Controller
    {

        //重写OnActionExecuting方法，这个方法在Action执行时执行
        protected override void OnActionExecuting(ActionExecutingContext filterContext)
        {
            //GetCurrentUserPrivilege();
            base.OnActionExecuting(filterContext);

            string controllerName = filterContext.Controller.ToString();//获取控制器名称
            string actionName = filterContext.ActionDescriptor.ActionName;//获取Action的名称
            //如果是用户请求登录页面则不验证权限
            if ((controllerName.Equals("OVS.Web.Controllers.UserController") && (actionName == "Login" || actionName == "Create")))
            {
                base.OnActionExecuting(filterContext);//执行mvc默认的行为
            }
            else
            {
                


                if (OVS.Web.Apps.AppHelper.LoginedUser == null)//如果登录信息丢失
                {
                    Redirect(filterContext);//跳转到登录页面
                    Response.End();//结束响应
                }
                else
                {
                    //限制普通用户权限
                    //if (AppHelper.LoginedUser.Role == "普通用户")
                    //{

                    //    if ((controllerName.Equals("OVS.Web.Controllers.VoteController") && (actionName == "Index" || actionName == "Result" || actionName == "Xuanze")))
                    //    {
                    //        base.OnActionExecuting(filterContext); //如果普通请求投票界面执行mvc默认的行为
                    //    }
                    //    else
                    //    {
                    //        Redirect(filterContext);//跳转到登录页面
                    //        Response.End();//结束响应
                    //    }
                    //}
                    //GetCurrentUserPrivilege();//设置动态属性，用于在母版页上显示菜单
                    base.OnActionExecuting(filterContext);
                }
            }

            


            //进行所有比赛状态判定修改
            IList< Competition> com = Container.Instance.Resolve<ICompetitionService>().GetAll();
            foreach (var item in com)
            {
                if (DateTime.Compare(item.BTime.AddSeconds(item.RTime), DateTime.Now) < 0 && item.IsActive == "进行中")
                {
                    //1.比赛结束修改
                    item.IsActive = "结束";
                    Container.Instance.Resolve<ICompetitionService>().Update(item);

                    //2.结果添加
                    Result result = new Result();
                    result.CompetitionId = item.ID;
                    //result.Playeringlist = playering.Competition.Playeringlist;
                    //2.1结果写入数据库
                    Container.Instance.Resolve<IResultService>().Create(result);
                }
            }

        }




        //页面跳转
        private void Redirect(ActionExecutingContext filterContext)
        {
            filterContext.HttpContext.Response.Redirect("~/User/Login?ReturnUrl=" + Server.UrlEncode(Request.Url.OriginalString), true);
        }
    }
}