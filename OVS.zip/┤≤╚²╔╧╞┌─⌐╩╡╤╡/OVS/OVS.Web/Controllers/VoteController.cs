﻿using NHibernate.Criterion;
using OVS.Core;
using OVS.Domain;
using OVS.Service;
using OVS.Web.Apps;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace OVS.Web.Controllers
{
    public class VoteController : BaseController
    {
        #region 投票界面
        public ActionResult Index(int pageIndex = 1)
        {
            //提供比赛
            IList<Competition> competition = Container.Instance.Resolve<ICompetitionService>().GetAll();
            ViewBag.themelist = competition;

            IList<Order> listOrder = new List<Order>() { new Order("ID", true) };//设置一个排序集合，new Order("ID", true)表示：根据ID排序,true代表升序,false代表降序
            int count = 0;//用于存放满足条件的记录总
            List<ICriterion> queryConditions = new List<ICriterion>();
            queryConditions.Add(Expression.Eq("Competition.ID", TempData["CompetitionId"]));
            IList<Playering> list = Container.Instance.Resolve<IPlayeringService>().GetPaged(queryConditions, listOrder, pageIndex, 20, out count);
            PageList<Playering> pageList = list.ToPageList<Playering>(pageIndex, 10, count);

            if (pageList == null||pageList.Count()==0)
            {
                return RedirectToAction("Xuanze");//跳转到Xuanze页面
            }
            else
            {
                return View(pageList);
            }
        }
        #endregion


        #region 投票
        public ActionResult Voting(int id, int pageIndex = 1)
        {
            int count = 0;//用于存放满足条件的记录总
            //根据id获取当前参加比赛选手
            Playering playering = Container.Instance.Resolve<IPlayeringService>().Get(id);
            List<ICriterion> queryConditions2 = new List<ICriterion>();
            queryConditions2.Add(Expression.Eq("Competition.ID", playering.Competition.ID));
            PageList<Playering> pageList = Container.Instance.Resolve<IPlayeringService>().GetPaged(queryConditions2, null, pageIndex, 20, out count).ToPageList<Playering>(pageIndex, 20, count);
                
            //根据用户ID和比赛ID判定
            List<ICriterion> queryConditions = new List<ICriterion>();
            queryConditions.Add(Expression.And(Expression.Eq("User.ID", AppHelper.LoginedUser.ID), Expression.Eq("Competition.ID", playering.Competition.ID)));
            //queryConditions.Add(Expression.Eq("User.ID", AppHelper.LoginedUser.ID));
            //判断用户是否重复投票
            if (!Container.Instance.Resolve<IVoteService>().Exists(queryConditions))
            {
                //保存用户投票记录
                Vote vote = new Vote();
                vote.User = AppHelper.LoginedUser;
                vote.Player = Container.Instance.Resolve<IPlayerService>().Get(Container.Instance.Resolve<IPlayeringService>().Get(id).Player.ID);
                vote.Competition = playering.Competition;
                Container.Instance.Resolve<IVoteService>().Create(vote);

                //修改比赛选手票数
                
                List<ICriterion> queryConditions1 = new List<ICriterion>();
                queryConditions1.Add(Expression.Eq("Player.ID", playering.Player.ID));
                queryConditions1.Add(Expression.Eq("Competition.ID", playering.Competition.ID));
                playering.Poll = Container.Instance.Resolve<IVoteService>().GetPaged(queryConditions1, null, pageIndex, 20, out count).Count();
                Container.Instance.Resolve<IPlayeringService>().Update(playering);

                //重新查询更新页面票数
                List<ICriterion> queryConditions21 = new List<ICriterion>();
                queryConditions21.Add(Expression.Eq("Competition.ID", playering.Competition.ID));
                PageList<Playering> pageLists = Container.Instance.Resolve<IPlayeringService>().GetPaged(queryConditions2, null, pageIndex, 20, out count).ToPageList<Playering>(pageIndex, 20, count);

                return  View("Index", pageLists);//跳转到Index页面
            }

            return Content("<script>alert('你已经投过票了在本场比赛比赛！！');location.href='/Vote/Xuanze'</script>");//跳转到Index页面

        }
        #endregion

        #region 用户选择界面
        [HttpGet]
        public ActionResult Xuanze()
        {
            //提供比赛
            IList<Competition> competition = Container.Instance.Resolve<ICompetitionService>().GetAll();
            ViewBag.themelist = competition;

            return View();
        }
        //[HttpPost]
        //public ActionResult TEST(string competitionId)
        //{
           
           
        //        return Content("<script>alert('该比赛已结束！！');location.href='/Vote/Result'</script>");
            
        //}
        [HttpPost]
        public ActionResult Xuanze(string competitionId)
        {
            if (competitionId == null)
            {
                return Content("<script>alert('请选择比赛！！');location.href='/Vote/Xuanze'</script>");
            }
            Competition competition = Container.Instance.Resolve<ICompetitionService>().Get(int.Parse(competitionId));
            if (competition.IsActive == "进行中" && DateTime.Compare(competition.BTime.AddSeconds(competition.RTime), DateTime.Now) >= 0)
            {
                TempData["CompetitionId"] = int.Parse(competitionId);
                
                return RedirectToAction("Index");//跳转到Index页面
            }
            else 
            {
                //1.比赛结束修改
                competition.IsActive = "结束";
                Container.Instance.Resolve<ICompetitionService>().Update(competition);

                //2.结果添加
                Result result = new Result();
                result.CompetitionId = competition.ID;
                //result.Playeringlist = playering.Competition.Playeringlist;
                //2.1结果写入数据库
                Container.Instance.Resolve<IResultService>().Create(result);

                //提供比赛
                IList<Competition> competitionName = Container.Instance.Resolve<ICompetitionService>().GetAll();
                ViewBag.themelist = competition;
                TempData["CompetitionId2"] = int.Parse(competitionId);
                return Content("<script>alert('该比赛已结束！！');location.href='/Vote/Result'</script>");
            }
        }

        #endregion

        #region 结果
        [HttpGet]
        public ActionResult Result(int pageIndex=1)
        {
            ////提供比赛
            //List<ICriterion> queryConditions = new List<ICriterion>();
            //queryConditions.Add(Expression.Eq("Competition.IsActive", ""));
            //IEnumerable<Competition> competition = Container.Instance.Resolve<ICompetitionService>().GetAll().Where(o => o.IsActive == "结束");
            
            //ViewBag.themelist = competition;

            List<ICriterion> queryConditions1 = new List<ICriterion>();
            queryConditions1.Add(Expression.Eq("Competition.ID", TempData["CompetitionId2"]));
            IList<Order> listOrder = new List<Order>() { new Order("Poll", false) };//设置一个排序集合，new Order("ID", true)表示：根据ID排序,true代表升序,false代表降序
            int count = 0;//用于存放满足条件的记录总
            IList<Playering> list = Container.Instance.Resolve<IPlayeringService>().GetPaged(queryConditions1, listOrder, pageIndex, PagerHelper.PageSize, out count);
            PageList<Playering> pageList = list.ToPageList<Playering>(pageIndex, PagerHelper.PageSize, count);
            return View(pageList);
        }
        [HttpPost]
        public ActionResult Result(int competitionId, int pageIndex = 1)
        {
            //提供比赛
            IEnumerable<Competition> competition = Container.Instance.Resolve<ICompetitionService>().GetAll().Where(o => o.IsActive == "结束");
            ViewBag.themelist = competition;

            List<ICriterion> queryConditions1 = new List<ICriterion>();
            queryConditions1.Add(Expression.Eq("Competition.ID", competitionId));
            IList<Order> listOrder = new List<Order>() { new Order("Poll", false) };//设置一个排序集合，new Order("ID", true)表示：根据ID排序,true代表升序,false代表降序
            int count = 0;//用于存放满足条件的记录总
            IList<Playering> list = Container.Instance.Resolve<IPlayeringService>().GetPaged(queryConditions1, listOrder, pageIndex, PagerHelper.PageSize, out count);
            PageList<Playering> pageList = list.ToPageList<Playering>(pageIndex, PagerHelper.PageSize, count);
            return View(pageList);

        }
        #endregion
    }
}