﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Castle.ActiveRecord;

using System.ComponentModel.DataAnnotations;

namespace OVS.Domain
{
    [ActiveRecord("SysUser")]
    public class User : EntityBase
    {
        [Property(NotNull = true)]
        [Required(ErrorMessage = "不能为空")]
        [StringLength(20, ErrorMessage = "不能超过20个字符")]
        [Display(Name = "用户名")]
        public virtual string UserName { get; set; }

        [Property(NotNull = true)]
        [Display(Name = "Age", Description = "年龄")]
        public virtual int Age { get; set; }

        [Property(NotNull = true)]
        [Required(ErrorMessage = "必须填写字段信息哦。")]
        [Display(Name = "Password", Description = "密码")]
        public virtual string Password { get; set; }

        //状态
        [Property(NotNull = true)]
        [Display(Name = "激活")]
        public virtual bool IsActive { get; set; }

        //账号
        [Property(NotNull = true, Length = 50)]
        [Required(ErrorMessage = "不能为空")]
        [StringLength(20, ErrorMessage = "不能超过50个字符")]
        [Display(Name = "帐号")]
        public virtual string Account { get; set; }

        [Property(NotNull = true)]
        [Required(ErrorMessage = "必须填写字段信息哦。")]
        [Display(Name = "Number", Description = "电话")]
        public virtual string Number { get; set; }

        [Property(NotNull = true)]
        [Required(ErrorMessage = "必须填写字段信息哦。")]
        [Display(Name = "Role", Description = "角色")]
        public virtual string Role { get; set; }
    }
}
