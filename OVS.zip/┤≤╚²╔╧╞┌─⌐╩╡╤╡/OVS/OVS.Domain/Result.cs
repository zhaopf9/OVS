﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Castle.ActiveRecord;

using System.ComponentModel.DataAnnotations;

namespace OVS.Domain
{
    [ActiveRecord("Result")]
    public class Result : EntityBase
    {
        [Property(NotNull = true)]
        [Required(ErrorMessage = "不能为空")]
        [Display(Name = "比赛ID")]
        public virtual int CompetitionId { get; set; }

    }
}
