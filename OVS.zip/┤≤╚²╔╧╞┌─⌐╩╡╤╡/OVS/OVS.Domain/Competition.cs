﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Castle.ActiveRecord;

using System.ComponentModel.DataAnnotations;

namespace OVS.Domain
{
    [ActiveRecord("Competition")]
    public class Competition:EntityBase
    {
        [Property(NotNull = true)]
        [Required(ErrorMessage = "不能为空")]
        [StringLength(20, ErrorMessage = "不能超过20个字符")]
        [Display(Name = "主题名")]
        public virtual string ThemeName { get; set; }

        //状态
        [Property(NotNull = true)]
        [Required(ErrorMessage = "必须填写字段信息哦。")]
        [Display(Name = "状态")]
        public virtual string IsActive { get; set; }

        [HasMany(typeof(Playering), Table = "Playering", ColumnKey = "CompetitionId", Cascade = ManyRelationCascadeEnum.All, Lazy = true, Inverse = false)]
        public IList<Playering> Playeringlist { get; set; }

        [Property(NotNull = true)]
        [Required(ErrorMessage = "不能为空")]
        [Display(Name = "进行中时间")]
        public virtual DateTime BTime { get; set; }

        [Property(NotNull = true)]
        [Required(ErrorMessage = "不能为空")]
        [Display(Name = "时长")]
        public virtual int RTime { get; set; }

        [Property(NotNull = true)]
        [Required(ErrorMessage = "不能为空")]
        [Display(Name = "地点")]
        public virtual string Place { get; set; }

        [HasMany(typeof(Vote), Table = "Vote", ColumnKey = "CompetitionId", Cascade = ManyRelationCascadeEnum.Delete, Lazy = true, Inverse = false)]
        public IList<Vote> Votelist { get; set; }
    }
}
