﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Castle.ActiveRecord;

using System.ComponentModel.DataAnnotations;

namespace OVS.Domain
{
    [ActiveRecord("Vote")]
    public class Vote:EntityBase
    {
        //参赛者
        [BelongsTo(Type = typeof(Player), Column = "PlayerId", Lazy = FetchWhen.OnInvoke)]
        public Player Player { get; set; }

        //投票者
        [BelongsTo(Type = typeof(User), Column = "UserId", Lazy = FetchWhen.OnInvoke)]
        public User User { get; set; }

        //主题
        [BelongsTo(Type = typeof(Competition), Column = "CompetitionId", Lazy = FetchWhen.OnInvoke)]
        public Competition Competition { get; set; }
    }
}
